#!/usr/bin/env Rscript
#====================================================
require(ggpubr)
jet.colors <-colorRampPalette(c('#00007F','blue','#007FFF','cyan','#7FFF7F','yellow','#FF7F00','red','#7F0000'))

#====================================================
atom_lrd='sys0.atom_lrd'
rc1_name='RC (C98--H107--O51)'
df1 <-read.table(atom_lrd,header=T)
#====================================================
grc1_0 <-ggplot(df1,aes(x=RC1,y=HOF) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('HOF \n(kCal/mol)') + 
	xlab(rc1_name)

#---------------------------------------------------
grc1_1 <-ggplot(df1,aes(x=RC1,y=ECP) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('ECP (eV)') + 
	xlab(rc1_name)

#---------------------------------------------------
grc1_2 <-ggplot(df1,aes(x=RC1,y=Hardness) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('Hardness \n(eV)') + 
	xlab(rc1_name)

#---------------------------------------------------
grc1_3 <-ggplot(df1,aes(x=RC1,y=Softness) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('Softness \n(eV)') + 
	xlab(rc1_name)

#---------------------------------------------------
grc1_4 <-ggplot(df1,aes(x=RC1,y=Electrophilicity) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('Electrophilicity \n(eV)') + 
	xlab(rc1_name)

#---------------------------------------------------
grc1_5 <-ggplot(df1,aes(x=RC1,y=Energy) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('Energy \n(eV)') + 
	xlab(rc1_name)

#---------------------------------------------------
png('global_rc1.png',width=6.5,height=5,units='in',res=1000)
ggarrange(grc1_0,grc1_1,grc1_2,grc1_3,grc1_4,grc1_5,ncol=3,nrow=2)
dev.off()
#====================================================
la_0 <-ggplot(df1,aes(x=RC1,y=O51_Nphilicity) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nNucleophilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_1 <-ggplot(df1,aes(x=RC1,y=O51_Ephilicity) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nElectrophilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_2 <-ggplot(df1,aes(x=RC1,y=O51_NET) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nNetphilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_3 <-ggplot(df1,aes(x=RC1,y=O51_Soft) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nSoftness') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_4 <-ggplot(df1,aes(x=RC1,y=O51_hard_lcp) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nHardness\n(LCP)') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_5 <-ggplot(df1,aes(x=RC1,y=O51_hard_Vee) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nHardness\n(Vee)') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_6 <-ggplot(df1,aes(x=RC1,y=O51_Fukui_pot) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nFukui\nPotential') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_7 <-ggplot(df1,aes(x=RC1,y=O51_ED) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nElectron\nDensity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_8 <-ggplot(df1,aes(x=RC1,y=O51_chg) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nPartial\nCharge') + 
	xlab(rc1_name)  
#---------------------------------------------------
png('la_0.png',width=8,height=7,units='in',res=1000)
ggarrange(la_0,la_1,la_2,la_3,la_4,la_5,la_6,la_7,la_8,ncol=3,nrow=3)
dev.off()
#====================================================
la_9 <-ggplot(df1,aes(x=RC1,y=O51_Fukui_pot_right) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nFukui\nPotential_Right') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_10 <-ggplot(df1,aes(x=RC1,y=O51_Fukui_pot_zero) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nFukui\nPotential_Zero') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_11 <-ggplot(df1,aes(x=RC1,y=O51_MEP) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\nMEP') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_12 <-ggplot(df1,aes(x=RC1,y=O51_Hardness_TFD) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('O51\Hardness\nTFD') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_13 <-ggplot(df1,aes(x=RC1,y=C98_Nphilicity) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nNucleophilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_14 <-ggplot(df1,aes(x=RC1,y=C98_Ephilicity) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nElectrophilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_15 <-ggplot(df1,aes(x=RC1,y=C98_NET) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nNetphilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_16 <-ggplot(df1,aes(x=RC1,y=C98_Soft) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nSoftness') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_17 <-ggplot(df1,aes(x=RC1,y=C98_hard_lcp) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nHardness\n(LCP)') + 
	xlab(rc1_name)  
#---------------------------------------------------
png('la_1.png',width=8,height=7,units='in',res=1000)
ggarrange(la_9,la_10,la_11,la_12,la_13,la_14,la_15,la_16,la_17,ncol=3,nrow=3)
dev.off()
#====================================================
la_18 <-ggplot(df1,aes(x=RC1,y=C98_hard_Vee) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nHardness\n(Vee)') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_19 <-ggplot(df1,aes(x=RC1,y=C98_Fukui_pot) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nFukui\nPotential') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_20 <-ggplot(df1,aes(x=RC1,y=C98_ED) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nElectron\nDensity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_21 <-ggplot(df1,aes(x=RC1,y=C98_chg) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nPartial\nCharge') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_22 <-ggplot(df1,aes(x=RC1,y=C98_Fukui_pot_right) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nFukui\nPotential_Right') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_23 <-ggplot(df1,aes(x=RC1,y=C98_Fukui_pot_zero) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nFukui\nPotential_Zero') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_24 <-ggplot(df1,aes(x=RC1,y=C98_MEP) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\nMEP') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_25 <-ggplot(df1,aes(x=RC1,y=C98_Hardness_TFD) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('C98\Hardness\nTFD') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_26 <-ggplot(df1,aes(x=RC1,y=H107_Nphilicity) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nNucleophilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
png('la_2.png',width=8,height=7,units='in',res=1000)
ggarrange(la_18,la_19,la_20,la_21,la_22,la_23,la_24,la_25,la_26,ncol=3,nrow=3)
dev.off()
#====================================================
la_27 <-ggplot(df1,aes(x=RC1,y=H107_Ephilicity) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nElectrophilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_28 <-ggplot(df1,aes(x=RC1,y=H107_NET) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nNetphilicity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_29 <-ggplot(df1,aes(x=RC1,y=H107_Soft) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nSoftness') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_30 <-ggplot(df1,aes(x=RC1,y=H107_hard_lcp) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nHardness\n(LCP)') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_31 <-ggplot(df1,aes(x=RC1,y=H107_hard_Vee) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nHardness\n(Vee)') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_32 <-ggplot(df1,aes(x=RC1,y=H107_Fukui_pot) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nFukui\nPotential') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_33 <-ggplot(df1,aes(x=RC1,y=H107_ED) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nElectron\nDensity') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_34 <-ggplot(df1,aes(x=RC1,y=H107_chg) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nPartial\nCharge') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_35 <-ggplot(df1,aes(x=RC1,y=H107_Fukui_pot_right) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nFukui\nPotential_Right') + 
	xlab(rc1_name)  
#---------------------------------------------------
png('la_3.png',width=8,height=7,units='in',res=1000)
ggarrange(la_27,la_28,la_29,la_30,la_31,la_32,la_33,la_34,la_35,ncol=3,nrow=3)
dev.off()
#====================================================
la_36 <-ggplot(df1,aes(x=RC1,y=H107_Fukui_pot_zero) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nFukui\nPotential_Zero') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_37 <-ggplot(df1,aes(x=RC1,y=H107_MEP) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\nMEP') + 
	xlab(rc1_name)  
#---------------------------------------------------
la_38 <-ggplot(df1,aes(x=RC1,y=H107_Hardness_TFD) )+
 	geom_point()+ 
	geom_line()+ 
	theme_minimal()+ 
	ylab('H107\Hardness\nTFD') + 
	xlab(rc1_name)  
#---------------------------------------------------
