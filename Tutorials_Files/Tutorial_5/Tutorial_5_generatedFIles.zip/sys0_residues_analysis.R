#!/usr/bin/env Rscript
require(ggpubr)
data_stat <-read.table('residues_data_stat',header=T) 
avg <-subset(data_stat,type=='AVG')
sd <-subset(data_stat,type=='SD')
#-------------------------------------
p1 <-ggplot( avg, aes(x=res, y=Nucleophilicity) ) +
geom_bar(stat='identity', color='black',fill='blue', position=position_dodge() ) +
	theme_minimal()+
	ylab('Nucleophilicity')+
	xlab('Residues')+
	geom_errorbar(aes(ymin=Nucleophilicity-sd$Nucleophilicity,ymax=Nucleophilicity+sd$Nucleophilicity), width=.2, position=position_dodge(.9))
#-------------------------------------
p2 <-ggplot(avg, aes(x=res, y=Electrophilicity)) +
	geom_bar(stat='identity', color='black',fill='red', position=position_dodge() ) +
	theme_minimal()+
	ylab('Electrophilicity')+
	xlab('Residues')+
	geom_errorbar(aes(ymin=Electrophilicity-sd$Electrophilicity,ymax=Electrophilicity+sd$Electrophilicity), width=.2, position=position_dodge(.9))
#-------------------------------------
p3 <-ggplot(avg, aes(x=res, y=Netphilicity)) +
	geom_bar(stat='identity', color='black',fill='lightgreen', position=position_dodge() ) +
	theme_minimal()+
	ylab('Netphilicity')+
	xlab('Residues')+
	geom_errorbar(aes(ymin=Netphilicity-sd$Netphilicity,ymax=Netphilicity+sd$Netphilicity), width=.2, position=position_dodge(.9))
#-------------------------------------
p4 <-ggplot(avg, aes(x=res, y=Hardness_Vee)) +
	geom_bar(stat='identity', color='black',fill='orange', position=position_dodge() ) +
	theme_minimal()+
	ylab('Hardness Vee')+
	xlab('Residues')+
	geom_errorbar(aes(ymin=Hardness_Vee-sd$Hardness_Vee,ymax=Hardness_Vee+sd$Hardness_Vee), width=.2, position=position_dodge(.9))
#-------------------------------------
p5 <-ggplot(avg, aes(x=res, y=Hardness_LCP)) +
	geom_bar(stat='identity', color='black',fill='aquamarine3', position=position_dodge() ) +
	theme_minimal()+
	ylab('Hardness LCP')+
	xlab('Residues')+
	geom_errorbar(aes(ymin=Hardness_LCP-sd$Hardness_LCP,ymax=Hardness_LCP+sd$Hardness_LCP), width=.2, position=position_dodge(.9))
#-------------------------------------
p6 <-ggplot(avg, aes(x=res, y=Fukui_pot_left)) +
	geom_bar(stat='identity', color='black',fill='blueviolet', position=position_dodge() ) +
	theme_minimal()+
	ylab('Fukui Potential Left')+
	xlab('Residues')+
	geom_errorbar(aes(ymin=Fukui_pot_left-sd$Fukui_pot_left,ymax=Fukui_pot_left+sd$Fukui_pot_left), width=.2, position=position_dodge(.9))
#-------------------------------------
p7 <-ggplot(avg, aes(x=res, y=Electron_Density)) +
	geom_bar(stat='identity', color='black',fill='springgreen3', position=position_dodge() ) +
	theme_minimal()+
	ylab('Electron Density')+
	xlab('Residues')+
	geom_errorbar(aes(ymin=Electron_Density-sd$Electron_Density,ymax=Electron_Density+sd$Electron_Density), width=.2, position=position_dodge(.9))
#-------------------------------------
png('Nph_res.png',units='in',res=1000,width=4.5,height=4)
p1
dev.off()
png('Eph_res.png',units='in',res=1000,width=4.5,height=4)
p2
dev.off()
png('NET_res.png',units='in',res=1000,width=4.5,height=4)
p3
dev.off()
png('Hardness_Vee_res.png',units='in',res=1000,width=4.5,height=4)
p4
dev.off()
png('Hardness_LCP_res.png',units='in',res=1000,width=4.5,height=4)
p5
dev.off()
png('Fukui_pot_res.png',units='in',res=1000,width=4.5,height=4)
p6
dev.off()
png('Electron_dens_res.png',units='in',res=1000,width=4.5,height=4)
p7
dev.off()
#=====================================================
dat <-read.table('residues_data_frames',header=T)
#-------------------------------------
pm1<-ggplot(dat, aes(x = frame, y = Electrophilicity) )+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('Electrophiliicty')+
	xlab('Frame')
#-------------------------------------
pm2<-ggplot(dat, aes(x = frame, y = Nucleophilicity ) )+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('Nucleophilicity')+
	xlab('Frame')
#-------------------------------------
pm3<-ggplot(dat, aes(x = frame, y =Netphilicity ))+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('Netphilicity')+
	xlab('Frame')
#-------------------------------------
pm4<-ggplot(dat, aes(x = frame, y =Hardness_Vee ))+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('Hardness Vee')+
	xlab('Frame')
#-------------------------------------
pm5<-ggplot(dat, aes(x = frame, y =Hardness_LCP ))+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('Hardness LCP')+
	xlab('Frame')
#-------------------------------------
pm6<-ggplot(dat, aes(x = frame, y =Fukui_pot_left))+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('Fukui Potential')+
	xlab('Frame')
#-------------------------------------
pm7<-ggplot(dat, aes(x = frame, y =hyper_softness ))+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('hyper_softness')+
	xlab('Frame')
#-------------------------------------
pm8<-ggplot(dat, aes(x = frame, y =Electron_Density ))+
	theme_minimal()+
	geom_point(aes(color=res))+
	geom_smooth(aes(color=res),method='loess')+
	ylab('Electron Density')+
	xlab('Frame')
#-------------------------------------
wdht = 5
png('nucleophilicity_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm1
dev.off()
#-------------------------------------
png('electrophilicity_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm2
dev.off()
#-------------------------------------
png('net_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm3
dev.off()
#-------------------------------------
png('hard_Vee_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm4
dev.off()
#-------------------------------------
png('hard_LCP_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm5
dev.off()
#-------------------------------------
png('Fukui_pot_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm6
dev.off()
#-------------------------------------
png('Hsoftness_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm7
dev.off()
#-------------------------------------
png('ED_mov_avg.png',units='in',res=1000,width=wdht,height=4)
pm8
dev.off()
#-------------------------------------
